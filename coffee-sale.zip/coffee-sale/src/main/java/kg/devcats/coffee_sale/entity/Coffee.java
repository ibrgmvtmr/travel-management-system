package kg.devcats.coffee_sale.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "coffees")
public class Coffee {

    @EmbeddedId
    @NotNull(message = "Coffee ID must not be null")
    private CoffeeId id;

    @MapsId("supId")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sup_id", nullable = false)
    @NotNull(message = "Supplier must not be null")
    private Supplier supplier;

    @PositiveOrZero(message = "Price must be zero or positive")
    @Column(name = "price")
    private float price;

    @NotNull(message = "Sales must not be null")
    @PositiveOrZero(message = "Sales must be zero or positive")
    @Column(name = "sales")
    private Integer sales;

    @NotNull(message = "Total must not be null")
    @PositiveOrZero(message = "Total must be zero or positive")
    @Column(name = "total")
    private Integer total;


    public Coffee() {}

    public CoffeeId getId() {
        return id;
    }

    public void setId(CoffeeId id) {
        this.id = id;
    }

    public Supplier getSupplier() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public Integer getSales() {
        return sales;
    }

    public void setSales(Integer sales) {
        this.sales = sales;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }
}