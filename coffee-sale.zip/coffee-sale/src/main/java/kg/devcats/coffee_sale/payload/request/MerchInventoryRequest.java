package kg.devcats.coffee_sale.payload.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.PositiveOrZero;

import java.time.LocalDate;

public record MerchInventoryRequest(

        @NotNull(message = "Item ID is required")
        Long itemId,

        @NotBlank(message = "Item name is required")
        String itemName,

        @NotNull(message = "Supplier ID is required")
        Integer supId,

        @PositiveOrZero(message = "Quantity must be zero or positive")
        Integer quantity,

        @PastOrPresent(message = "Last updated date must be in the past or present")
        LocalDate lastUpdated

) {}
