package kg.devcats.coffee_sale.repository;

import kg.devcats.coffee_sale.entity.MerchInventory;
import kg.devcats.coffee_sale.entity.Supplier;
import kg.devcats.coffee_sale.payload.request.MerchInventoryRequest;
import kg.devcats.coffee_sale.payload.response.MerchInventoryResponse;
import kg.devcats.coffee_sale.repository.jpa.h2.MerchInventoryH2Jpa;
import kg.devcats.coffee_sale.repository.jpa.postgres.MerchInventoryPostgresJpa;
import kg.devcats.coffee_sale.repository.jpa.postgres.SupplierPostgresJpa;
import kg.devcats.coffee_sale.service.MerchInventoryService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class MerchInventoryRepository implements MerchInventoryService {

    private final MerchInventoryPostgresJpa postgresRepo;
    private final MerchInventoryH2Jpa h2Repo;
    private final SupplierPostgresJpa supplierRepo;

    public MerchInventoryRepository(MerchInventoryPostgresJpa postgresRepo,
                                    MerchInventoryH2Jpa h2Repo,
                                    SupplierPostgresJpa supplierRepo) {
        this.postgresRepo = postgresRepo;
        this.h2Repo = h2Repo;
        this.supplierRepo = supplierRepo;
    }

    @Transactional
    public MerchInventoryResponse create(MerchInventoryRequest request) {
        Supplier supplier = supplierRepo.findById(request.supId())
                .orElseThrow(() -> new RuntimeException("Supplier not found"));

        MerchInventory entityPostgres = mapToEntity(request, supplier);
        MerchInventory savedPostgres = postgresRepo.save(entityPostgres);

        MerchInventory entityH2 = new MerchInventory();
        entityH2.setItemName(savedPostgres.getItemName());
        entityH2.setSupplier(savedPostgres.getSupplier());
        entityH2.setQuantity(savedPostgres.getQuantity());
        entityH2.setLastUpdated(savedPostgres.getLastUpdated());

        h2Repo.save(entityH2);

        return mapToResponse(savedPostgres);
    }



    @Override
    public MerchInventoryResponse getById(Long itemId) {
        MerchInventory inv = postgresRepo.findById(itemId)
                .orElseThrow(() -> new RuntimeException("Item not found"));
        return mapToResponse(inv);
    }

    @Override
    public List<MerchInventoryResponse> getAll() {
        List<MerchInventory> list = postgresRepo.findAll();
        List<MerchInventoryResponse> result = new ArrayList<>();
        for (MerchInventory m : list) {
            result.add(mapToResponse(m));
        }
        return result;
    }

    @Override
    public MerchInventoryResponse update(Long itemId, MerchInventoryRequest request) {
        MerchInventory inv = postgresRepo.findById(itemId)
                .orElseThrow(() -> new RuntimeException("Item not found"));

        inv.setItemName(request.itemName());
        inv.setQuantity(request.quantity());
        inv.setLastUpdated(request.lastUpdated());

        MerchInventory updated = postgresRepo.save(inv);
        h2Repo.save(inv);
        return mapToResponse(updated);
    }

    @Override
    public void delete(Long itemId) {
        postgresRepo.deleteById(itemId);
        h2Repo.deleteByItemId(itemId);
    }

    private MerchInventory mapToEntity(MerchInventoryRequest r, Supplier supplier) {
        MerchInventory m = new MerchInventory();
        m.setItemId(r.itemId());
        m.setItemName(r.itemName());
        m.setSupplier(supplier);
        m.setQuantity(r.quantity());
        m.setLastUpdated(r.lastUpdated());
        return m;
    }

    private MerchInventoryResponse mapToResponse(MerchInventory m) {
        return new MerchInventoryResponse(
                m.getItemId(),
                m.getItemName(),
                m.getSupplier().getSupId(),
                null,
                m.getQuantity(),
                m.getLastUpdated()
        );
    }
}

