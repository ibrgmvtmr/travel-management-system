package kg.devcats.coffee_sale;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoffeeSaleApplication {

    public static void main(String[] args) {
        SpringApplication.run(CoffeeSaleApplication.class, args);
    }

}
