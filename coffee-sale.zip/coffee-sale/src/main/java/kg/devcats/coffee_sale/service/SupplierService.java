package kg.devcats.coffee_sale.service;

import kg.devcats.coffee_sale.payload.request.SupplierRequest;
import kg.devcats.coffee_sale.payload.response.SupplierResponse;

import java.util.List;

public interface SupplierService {

    SupplierResponse create(SupplierRequest request);

    SupplierResponse getById(Integer supId);

    List<SupplierResponse> getAll();

    SupplierResponse update(Integer supId, SupplierRequest request);

    void delete(Integer supId);
}
