package kg.devcats.coffee_sale.controller.api;

import jakarta.validation.Valid;
import kg.devcats.coffee_sale.payload.request.SupplierRequest;
import kg.devcats.coffee_sale.payload.response.SupplierResponse;
import kg.devcats.coffee_sale.service.SupplierService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Validated
@RestController
@RequestMapping("/api/suppliers")
public class SupplierController {

    private final SupplierService supplierService;

    public SupplierController(SupplierService supplierService) {
        this.supplierService = supplierService;
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    public ResponseEntity<String> create(@Valid @RequestBody SupplierRequest request) {
        supplierService.create(request);
        return ResponseEntity.status(HttpStatus.CREATED).body("Supplier successfully created");
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    public ResponseEntity<SupplierResponse> getById(@PathVariable("id") Integer supId) {
        SupplierResponse response = supplierService.getById(supId);
        return ResponseEntity.ok(response);
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    public ResponseEntity<List<SupplierResponse>> getAll() {
        List<SupplierResponse> responses = supplierService.getAll();
        return ResponseEntity.ok(responses);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    public ResponseEntity<String> update(@PathVariable("id") Integer supId,
                                         @Valid @RequestBody SupplierRequest request) {
        supplierService.update(supId, request);
        return ResponseEntity.ok("Supplier successfully updated");
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    public ResponseEntity<String> delete(@PathVariable("id") Integer supId) {
        supplierService.delete(supId);
        return ResponseEntity.ok("Supplier successfully deleted");
    }
}
