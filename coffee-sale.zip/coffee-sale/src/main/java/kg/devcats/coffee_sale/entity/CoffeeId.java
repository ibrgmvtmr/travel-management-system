package kg.devcats.coffee_sale.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class CoffeeId implements Serializable {

    @NotBlank
    @Column(name = "cof_name", length = 32)
    private String cofName;

    @NotNull
    @Column(name = "sup_id")
    private Integer supId;

    public CoffeeId() {}

    public CoffeeId(String cofName, Integer supId) {
        this.cofName = cofName;
        this.supId = supId;
    }

    public String getCofName() {
        return cofName;
    }

    public void setCofName(String cofName) {
        this.cofName = cofName;
    }

    public Integer getSupId() {
        return supId;
    }

    public void setSupId(Integer supId) {
        this.supId = supId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CoffeeId)) return false;
        CoffeeId that = (CoffeeId) o;
        return Objects.equals(cofName, that.cofName) && Objects.equals(supId, that.supId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cofName, supId);
    }
}