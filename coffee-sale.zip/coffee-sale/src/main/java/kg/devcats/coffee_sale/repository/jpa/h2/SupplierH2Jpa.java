package kg.devcats.coffee_sale.repository.jpa.h2;

import kg.devcats.coffee_sale.entity.Supplier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SupplierH2Jpa extends JpaRepository<Supplier, Integer> {
}
