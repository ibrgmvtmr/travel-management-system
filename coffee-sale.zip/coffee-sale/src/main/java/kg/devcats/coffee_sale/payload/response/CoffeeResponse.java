package kg.devcats.coffee_sale.payload.response;

public record CoffeeResponse(
        String cofName,
        Integer supId,
        float price,
        Integer sales,
        Integer total
) {}