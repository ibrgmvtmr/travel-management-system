package kg.devcats.coffee_sale.controller.mvc;

import kg.devcats.coffee_sale.payload.request.CoffeeInventoryRequest;
import kg.devcats.coffee_sale.payload.response.CoffeeInventoryResponse;
import kg.devcats.coffee_sale.service.CoffeeInventoryService;
import kg.devcats.coffee_sale.service.MerchInventoryService;
import kg.devcats.coffee_sale.service.SupplierService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/coffee-inventory")
public class CoffeeInventoryControllerMvc {

    private final CoffeeInventoryService coffeeInventoryService;
    private final MerchInventoryService merchInventoryService;
    private final SupplierService supplierService;

    public CoffeeInventoryControllerMvc(CoffeeInventoryService coffeeInventoryService,
                                        MerchInventoryService merchInventoryService,
                                        SupplierService supplierService) {
        this.coffeeInventoryService = coffeeInventoryService;
        this.merchInventoryService = merchInventoryService;
        this.supplierService = supplierService;
    }

    @GetMapping
    public String list(Model model) {
        List<CoffeeInventoryResponse> all = coffeeInventoryService.getAll();
        model.addAttribute("inventories", all);
        return "coffeeinventory/list";
    }

    @GetMapping("/create")
    public String showCreateForm(Model model) {
        model.addAttribute("inventory", new CoffeeInventoryRequest(null, "", null, 0, null));
        // Добавляем список поставщиков в модель
        model.addAttribute("suppliers", supplierService.getAll());
        return "coffeeinventory/create";
    }

    @PostMapping("/create")
    public String create(@ModelAttribute CoffeeInventoryRequest request) {
        coffeeInventoryService.create(request);
        return "redirect:/coffee-inventory";
    }

    @GetMapping("/edit")
    public String showEditForm(
            @RequestParam Integer warehouseId,
            @RequestParam String cofName,
            @RequestParam Integer supId,
            Model model
    ) {
        CoffeeInventoryResponse response = coffeeInventoryService.getById(warehouseId, cofName, supId);
        CoffeeInventoryRequest request = new CoffeeInventoryRequest(
                response.warehouseId(),
                response.cofName(),
                response.supId(),
                response.quantity(),
                response.lastUpdated()
        );
        model.addAttribute("inventory", request);
        // Добавляем список поставщиков для выпадающего списка в форме редактирования
        model.addAttribute("suppliers", supplierService.getAll());
        return "coffeeinventory/edit";
    }

    @PostMapping("/edit")
    public String update(@ModelAttribute CoffeeInventoryRequest request) {
        coffeeInventoryService.update(
                request.warehouseId(),
                request.cofName(),
                request.supId(),
                request
        );
        return "redirect:/coffee-inventory";
    }

    @GetMapping("/delete")
    public String delete(
            @RequestParam Integer warehouseId,
            @RequestParam String cofName,
            @RequestParam Integer supId
    ) {
        coffeeInventoryService.delete(warehouseId, cofName, supId);
        return "redirect:/coffee-inventory";
    }
}
