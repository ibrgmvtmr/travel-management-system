package kg.devcats.coffee_sale.repository.jpa.postgres;

import kg.devcats.coffee_sale.entity.CoffeeHouse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CoffeeHousePostgresJpa extends JpaRepository<CoffeeHouse, Integer> {
}
