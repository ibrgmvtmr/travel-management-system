package kg.devcats.coffee_sale.payload.response;

import java.time.LocalDate;

public record CoffeeInventoryResponse(
        Integer warehouseId,
        String cofName,
        Integer supId,
        Integer quantity,
        LocalDate lastUpdated
) {}
