package kg.devcats.coffee_sale.payload.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

public record CoffeeRequest(

        @NotBlank(message = "Coffee name is required")
        String cofName,

        @NotNull(message = "Supplier ID is required")
        Integer supId,

        @PositiveOrZero(message = "Price must be zero or positive")
        float price,

        @PositiveOrZero(message = "Sales must be zero or positive")
        Integer sales,

        @PositiveOrZero(message = "Total must be zero or positive")
        Integer total

) {}
