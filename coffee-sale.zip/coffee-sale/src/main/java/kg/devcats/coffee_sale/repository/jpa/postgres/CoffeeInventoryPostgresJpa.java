package kg.devcats.coffee_sale.repository.jpa.postgres;

import kg.devcats.coffee_sale.entity.CoffeeInventory;
import kg.devcats.coffee_sale.entity.CoffeeInventoryId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CoffeeInventoryPostgresJpa extends JpaRepository<CoffeeInventory, CoffeeInventoryId> {
}
