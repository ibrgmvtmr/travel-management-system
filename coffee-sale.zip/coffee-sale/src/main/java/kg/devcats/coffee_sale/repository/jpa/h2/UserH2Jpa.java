package kg.devcats.coffee_sale.repository.jpa.h2;

import kg.devcats.coffee_sale.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserH2Jpa extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
}
