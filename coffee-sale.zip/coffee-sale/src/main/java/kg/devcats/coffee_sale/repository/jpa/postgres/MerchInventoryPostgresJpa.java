package kg.devcats.coffee_sale.repository.jpa.postgres;

import jakarta.persistence.LockModeType;
import kg.devcats.coffee_sale.entity.MerchInventory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface MerchInventoryPostgresJpa extends JpaRepository<MerchInventory, Long> {

    @Lock(LockModeType.OPTIMISTIC)
    Optional<MerchInventory> findById(Long id);
}
