package kg.devcats.coffee_sale.service.repository;

import kg.devcats.coffee_sale.entity.CoffeeHouse;
import kg.devcats.coffee_sale.payload.request.CoffeeHouseRequest;
import kg.devcats.coffee_sale.payload.response.CoffeeHouseResponse;
import kg.devcats.coffee_sale.repository.jpa.h2.CoffeeHouseH2Jpa;
import kg.devcats.coffee_sale.repository.jpa.postgres.CoffeeHousePostgresJpa;
import kg.devcats.coffee_sale.service.CoffeeHouseService;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class CoffeeHouseRepository implements CoffeeHouseService {

    private final CoffeeHousePostgresJpa postgresRepo;
    private final CoffeeHouseH2Jpa h2Repo;

    public CoffeeHouseRepository(CoffeeHousePostgresJpa postgresRepo, CoffeeHouseH2Jpa h2Repo) {
        this.postgresRepo = postgresRepo;
        this.h2Repo = h2Repo;
    }

    @Override
    public CoffeeHouseResponse create(CoffeeHouseRequest request) {
        CoffeeHouse ch = mapToEntity(request);
        CoffeeHouse saved = postgresRepo.save(ch);
        h2Repo.save(ch);
        return mapToResponse(saved);
    }

    @Override
    public CoffeeHouseResponse getById(Integer id) {
        CoffeeHouse ch = postgresRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Coffee house not found"));
        return mapToResponse(ch);
    }

    @Override
    public List<CoffeeHouseResponse> getAll() {
        List<CoffeeHouse> list = postgresRepo.findAll();
        List<CoffeeHouseResponse> result = new ArrayList<>();
        for (CoffeeHouse ch : list) {
            result.add(mapToResponse(ch));
        }
        return result;
    }

    @Override
    public CoffeeHouseResponse update(Integer id, CoffeeHouseRequest request) {
        CoffeeHouse ch = postgresRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Coffee house not found"));

        ch.setCity(request.city());
        ch.setCoffeeSales(request.coffeeSales());
        ch.setMerchSales(request.merchSales());
        ch.setTotalSales(request.totalSales());

        CoffeeHouse updated = postgresRepo.save(ch);
        h2Repo.save(ch);
        return mapToResponse(updated);
    }

    @Override
    public void delete(Integer id) {
        postgresRepo.deleteById(id);
        h2Repo.deleteById(id);
    }

    private CoffeeHouse mapToEntity(CoffeeHouseRequest r) {
        CoffeeHouse ch = new CoffeeHouse();
        ch.setId(r.id());
        ch.setCity(r.city());
        ch.setCoffeeSales(r.coffeeSales());
        ch.setMerchSales(r.merchSales());
        ch.setTotalSales(r.totalSales());
        return ch;
    }

    private CoffeeHouseResponse mapToResponse(CoffeeHouse c) {
        return new CoffeeHouseResponse(
                c.getId(),
                c.getCity(),
                c.getCoffeeSales(),
                c.getMerchSales(),
                c.getTotalSales()
        );
    }
}
