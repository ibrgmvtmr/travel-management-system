package kg.devcats.coffee_sale.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

@Entity
@Table(name = "coffee_houses")
public class CoffeeHouse {

    @Id
    @Column(name = "store_id")
    private Integer id;

    @NotBlank(message = "City must not be blank")
    @Column(name = "city")
    private String city;

    @NotNull(message = "Coffee sales must not be null")
    @PositiveOrZero(message = "Coffee sales must be zero or positive")
    @Column(name = "coffee")
    private Integer coffeeSales;

    @NotNull(message = "Merch sales must not be null")
    @PositiveOrZero(message = "Merch sales must be zero or positive")
    @Column(name = "merch")
    private Integer merchSales;

    @NotNull(message = "Total sales must not be null")
    @PositiveOrZero(message = "Total sales must be zero or positive")
    @Column(name = "total")
    private Integer totalSales;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public Integer getCoffeeSales() {
        return coffeeSales;
    }

    public void setCoffeeSales(Integer coffeeSales) {
        this.coffeeSales = coffeeSales;
    }

    public Integer getMerchSales() {
        return merchSales;
    }

    public void setMerchSales(Integer merchSales) {
        this.merchSales = merchSales;
    }

    public Integer getTotalSales() {
        return totalSales;
    }

    public void setTotalSales(Integer totalSales) {
        this.totalSales = totalSales;
    }
}
