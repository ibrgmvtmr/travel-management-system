package kg.devcats.coffee_sale.controller.mvc;

import kg.devcats.coffee_sale.payload.request.CoffeeRequest;
import kg.devcats.coffee_sale.payload.response.CoffeeResponse;
import kg.devcats.coffee_sale.service.CoffeeService;
import kg.devcats.coffee_sale.service.MerchInventoryService;
import kg.devcats.coffee_sale.service.SupplierService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/coffees")
public class CoffeeControllerMvc {

    private final CoffeeService coffeeService;
    private final SupplierService supplierService;
    private static final Logger logger = LoggerFactory.getLogger(CoffeeControllerMvc.class);

    public CoffeeControllerMvc(CoffeeService coffeeService, SupplierService supplierService) {
        this.coffeeService = coffeeService;
        this.supplierService = supplierService;
    }

    @GetMapping
    public String list(Model model) {
        List<CoffeeResponse> coffees = coffeeService.getAll();
        logger.info("Запрос списка кофе. Найдено: {}", coffees.size());
        model.addAttribute("coffees", coffees);
        model.addAttribute("suppliers", supplierService.getAll());
        return "coffee/list";
    }

    @GetMapping("/create")
    public String showCreateForm(Model model) {
        model.addAttribute("coffee", new CoffeeRequest(null, null, 0f, 0, 0));
        model.addAttribute("suppliers", supplierService.getAll());
        return "coffee/create";
    }

    @PostMapping("/create")
    public String create(@ModelAttribute CoffeeRequest request) {
        logger.info("Получен запрос на создание кофе: {}", request);
        try {
            CoffeeResponse created = coffeeService.create(request);
            logger.info("Кофе успешно создан: {}", created);
        } catch (Exception e) {
            logger.error("Ошибка при создании кофе: {}", e.getMessage(), e);
        }
        return "redirect:/coffees";
    }

    @GetMapping("/edit")
    public String showEditForm(@RequestParam("name") String cofName,
                               @RequestParam("supId") Integer supId,
                               Model model) {
        try {
            CoffeeResponse coffee = coffeeService.getById(cofName, supId);
            logger.info("Получены данные для редактирования кофе: {}", coffee);
            model.addAttribute("coffee", new CoffeeRequest(
                    coffee.cofName(),
                    coffee.supId(),
                    coffee.price(),
                    coffee.sales(),
                    coffee.total()
            ));
            model.addAttribute("originalName", cofName);
            model.addAttribute("originalSupId", supId);
        } catch (Exception e) {
            logger.error("Ошибка при получении данных кофе: {}", e.getMessage(), e);
        }
        return "coffee/edit";
    }

    @PostMapping("/edit")
    public String update(@RequestParam("originalName") String originalName,
                         @RequestParam("originalSupId") Integer originalSupId,
                         @ModelAttribute CoffeeRequest request) {
        logger.info("Получен запрос на обновление кофе. originalName: {}, originalSupId: {}, request: {}",
                originalName, originalSupId, request);
        try {
            CoffeeResponse updated = coffeeService.update(originalName, originalSupId, request);
            logger.info("Кофе успешно обновлён: {}", updated);
        } catch (Exception e) {
            logger.error("Ошибка при обновлении кофе: {}", e.getMessage(), e);
        }
        return "redirect:/coffees";
    }

    @PostMapping("/delete")
    public String delete(@RequestParam("name") String cofName,
                         @RequestParam("supId") Integer supId) {
        logger.info("Получен запрос на удаление кофе: cofName={}, supId={}", cofName, supId);
        try {
            coffeeService.delete(cofName, supId);
            logger.info("Кофе успешно удалён: cofName={}, supId={}", cofName, supId);
        } catch (Exception e) {
            logger.error("Ошибка при удалении кофе: {}", e.getMessage(), e);
        }
        return "redirect:/coffees";
    }
}
