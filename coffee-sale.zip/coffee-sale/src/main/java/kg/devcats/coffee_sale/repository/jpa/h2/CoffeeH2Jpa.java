package kg.devcats.coffee_sale.repository.jpa.h2;

import kg.devcats.coffee_sale.entity.Coffee;
import kg.devcats.coffee_sale.entity.CoffeeId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CoffeeH2Jpa extends JpaRepository<Coffee, CoffeeId> {
}
