package kg.devcats.coffee_sale.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;
import java.util.Objects;

@Entity
@Table(name = "merch_inventory")
public class MerchInventory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "item_id")
    private Long itemId;

    @NotBlank(message = "Item name must not be blank")
    @Column(name = "item_name", nullable = false)
    private String itemName;

    @NotNull(message = "Supplier must not be null")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sup_id", nullable = false)
    private Supplier supplier;

    @NotNull(message = "Quantity must not be null")
    @PositiveOrZero(message = "Quantity must be zero or positive")
    @Column(name = "quan", nullable = false)
    private Integer quantity;

    @NotNull(message = "Last updated date must not be null")
    @PastOrPresent(message = "Date must be in the past or present")
    @Column(name = "date", nullable = false)
    private LocalDate lastUpdated;

    @Version
    private Integer version;

    public MerchInventory() {
    }

    public MerchInventory(String itemName, Supplier supplier, Integer quantity, LocalDate lastUpdated) {
        this.itemName = itemName;
        this.supplier = supplier;
        this.quantity = quantity;
        this.lastUpdated = lastUpdated;
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Supplier getSupplier() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public LocalDate getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(LocalDate lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MerchInventory that = (MerchInventory) o;
        return Objects.equals(itemId, that.itemId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(itemId);
    }

    @Override
    public String toString() {
        return "MerchInventory{" +
                "itemId=" + itemId +
                ", itemName='" + itemName + '\'' +
                ", supplier=" + (supplier != null ? supplier.getSupId() : "null") +
                ", quantity=" + quantity +
                ", lastUpdated=" + lastUpdated +
                '}';
    }
}
