package kg.devcats.coffee_sale.repository;

import kg.devcats.coffee_sale.entity.Supplier;
import kg.devcats.coffee_sale.payload.request.SupplierRequest;
import kg.devcats.coffee_sale.payload.response.SupplierResponse;
import kg.devcats.coffee_sale.repository.jpa.h2.SupplierH2Jpa;
import kg.devcats.coffee_sale.repository.jpa.postgres.SupplierPostgresJpa;
import kg.devcats.coffee_sale.service.SupplierService;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class SupplierRepository implements SupplierService {

    private final SupplierPostgresJpa postgresRepo;
    private final SupplierH2Jpa h2Repo;

    public SupplierRepository(SupplierPostgresJpa postgresRepo, SupplierH2Jpa h2Repo) {
        this.postgresRepo = postgresRepo;
        this.h2Repo = h2Repo;
    }

    @Override
    public SupplierResponse create(SupplierRequest request) {
        Supplier supplier = mapToEntity(request);

        Supplier saved = postgresRepo.save(supplier);
        h2Repo.save(supplier); // дублируем в H2

        return mapToResponse(saved);
    }

    @Override
    public SupplierResponse getById(Integer supId) {
        Supplier supplier = postgresRepo.findById(supId)
                .orElseThrow(() -> new RuntimeException("Supplier not found in PostgreSQL"));
        return mapToResponse(supplier);
    }

    @Override
    public List<SupplierResponse> getAll() {
        List<Supplier> list = postgresRepo.findAll();
        List<SupplierResponse> result = new ArrayList<>();
        for (Supplier s : list) {
            result.add(mapToResponse(s));
        }
        return result;
    }

    @Override
    public SupplierResponse update(Integer supId, SupplierRequest request) {
        Supplier supplier = postgresRepo.findById(supId)
                .orElseThrow(() -> new RuntimeException("Supplier not found in PostgreSQL"));

        supplier.setSupName(request.supName());
        supplier.setStreet(request.street());
        supplier.setCity(request.city());
        supplier.setState(request.state());
        supplier.setZip(request.zip());

        Supplier updated = postgresRepo.save(supplier);
        h2Repo.save(supplier);

        return mapToResponse(updated);
    }

    @Override
    public void delete(Integer supId) {
        postgresRepo.deleteById(supId);
        h2Repo.deleteById(supId);
    }


    private Supplier mapToEntity(SupplierRequest req) {
        Supplier s = new Supplier();
        s.setSupId(req.supId());
        s.setSupName(req.supName());
        s.setStreet(req.street());
        s.setCity(req.city());
        s.setState(req.state());
        s.setZip(req.zip());
        return s;
    }

    private SupplierResponse mapToResponse(Supplier s) {
        return new SupplierResponse(
                s.getSupId(),
                s.getSupName(),
                s.getStreet(),
                s.getCity(),
                s.getState(),
                s.getZip()
        );
    }
}
