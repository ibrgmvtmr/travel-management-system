package kg.devcats.coffee_sale.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class CoffeeInventoryId implements Serializable {

    @NotNull(message = "Warehouse ID must not be null")
    @Column(name = "warehouse_id")
    private Integer warehouseId;

    @NotBlank(message = "Coffee name must not be blank")
    @Column(name = "cof_name", length = 32)
    private String coffeeName;

    @NotNull(message = "Supplier ID must not be null")
    @Column(name = "sup_id")
    private Integer supplierId;

    public Integer getWarehouseId() {
        return warehouseId;
    }

    public void setWarehouseId(Integer warehouseId) {
        this.warehouseId = warehouseId;
    }

    public String getCoffeeName() {
        return coffeeName;
    }

    public void setCoffeeName(String coffeeName) {
        this.coffeeName = coffeeName;
    }

    public Integer getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(Integer supplierId) {
        this.supplierId = supplierId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CoffeeInventoryId)) return false;
        CoffeeInventoryId that = (CoffeeInventoryId) o;
        return Objects.equals(warehouseId, that.warehouseId) &&
                Objects.equals(coffeeName, that.coffeeName) &&
                Objects.equals(supplierId, that.supplierId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(warehouseId, coffeeName, supplierId);
    }
}