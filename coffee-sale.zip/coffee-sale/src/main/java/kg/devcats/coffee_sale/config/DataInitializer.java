package kg.devcats.coffee_sale.config;

import jakarta.transaction.Transactional;
import kg.devcats.coffee_sale.payload.request.*;
import kg.devcats.coffee_sale.service.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class DataInitializer implements CommandLineRunner {

    private final SupplierService supplierService;
    private final CoffeeService coffeeService;
    private final CoffeeHouseService coffeeHouseService;
    private final CoffeeInventoryService coffeeInventoryService;
    private final MerchInventoryService merchInventoryService;

    public DataInitializer(SupplierService supplierService,
                           CoffeeService coffeeService,
                           CoffeeHouseService coffeeHouseService,
                           CoffeeInventoryService coffeeInventoryService,
                           MerchInventoryService merchInventoryService) {
        this.supplierService = supplierService;
        this.coffeeService = coffeeService;
        this.coffeeHouseService = coffeeHouseService;
        this.coffeeInventoryService = coffeeInventoryService;
        this.merchInventoryService = merchInventoryService;
    }

    @Override
    public void run(String... args) {
        initSuppliers();
        initCoffees();
        initCoffeeHouses();
        initCoffeeInventory();
        initMerchInventory();
    }

    private void initSuppliers() {
        addSupplierIfNotExists(1, "Jiraffe", "Советская 12", "Бишкек");
        addSupplierIfNotExists(2, "Shoro", "Тыналиева 45", "Каракол");
        addSupplierIfNotExists(3, "Kulikov", "Чуй 101", "Балыкчы");
        addSupplierIfNotExists(4, "Drippa", "Анкара 88", "Чолпон-Ата");
        addSupplierIfNotExists(5, "OneBucksCoffee", "Горького 7", "Токмок");
    }

    private void addSupplierIfNotExists(int id, String name, String street, String city) {
        try {
            supplierService.getById(id);
        } catch (RuntimeException e) {
            supplierService.create(new SupplierRequest(id, name, street, city, "Кыргызстан", "7200" + id));
        }
    }

    private void initCoffees() {
        addCoffeeIfNotExists("Espresso", 1, 120.0f, 350, 1500);
        addCoffeeIfNotExists("Latte", 2, 135.0f, 200, 800);
        addCoffeeIfNotExists("Cappuccino", 3, 140.0f, 400, 1600);
        addCoffeeIfNotExists("Americano", 4, 110.0f, 180, 900);
        addCoffeeIfNotExists("Mocha", 5, 150.0f, 90, 500);
    }

    private void addCoffeeIfNotExists(String name, Integer supId, float price, Integer sales, Integer total) {
        try {
            coffeeService.getById(name, supId);
        } catch (RuntimeException e) {
            coffeeService.create(new CoffeeRequest(name, supId, price, sales, total));
        }
    }

    private void initCoffeeHouses() {
        addCoffeeHouseIfNotExists(1, "Бишкек", 1000, 300, 1300);
        addCoffeeHouseIfNotExists(2, "Каракол", 800, 200, 1000);
        addCoffeeHouseIfNotExists(3, "Балыкчы", 600, 150, 750);
        addCoffeeHouseIfNotExists(4, "Чолпон-Ата", 900, 250, 1150);
        addCoffeeHouseIfNotExists(5, "Токмок", 700, 100, 800);
    }

    private void addCoffeeHouseIfNotExists(int id, String city, int coffee, int merch, int total) {
        try {
            coffeeHouseService.getById(id);
        } catch (RuntimeException e) {
            coffeeHouseService.create(new CoffeeHouseRequest(id, city, coffee, merch, total));
        }
    }

    private void initCoffeeInventory() {
        addCoffeeInventoryIfNotExists(101, "Espresso", 1, 400);
        addCoffeeInventoryIfNotExists(102, "Latte", 2, 300);
        addCoffeeInventoryIfNotExists(103, "Cappuccino", 3, 200);
        addCoffeeInventoryIfNotExists(104, "Americano", 4, 350);
        addCoffeeInventoryIfNotExists(105, "Mocha", 5, 250);
    }

    private void addCoffeeInventoryIfNotExists(int warehouseId, String cofName, int supId, int quantity) {
        try {
            coffeeInventoryService.getById(warehouseId, cofName, supId);
        } catch (RuntimeException e) {
            coffeeInventoryService.create(new CoffeeInventoryRequest(warehouseId, cofName, supId, quantity, LocalDate.now()));
        }
    }

    private void initMerchInventory() {
        addMerchIfNotExists(1L, "Термокружка", 1, 50);
        addMerchIfNotExists(2L, "Бутылка Shoro", 2, 30);
        addMerchIfNotExists(3L, "Футболка Kulikov", 3, 80);
        addMerchIfNotExists(4L, "Сумка Drippa", 4, 40);
        addMerchIfNotExists(5L, "Пакет зёрен", 5, 100);
    }

    @Transactional
    protected void addMerchIfNotExists(Long id, String name, int supId, int quantity) {
        try {
            merchInventoryService.getById(id);
        } catch (RuntimeException e) {
            merchInventoryService.create(new MerchInventoryRequest(null, name, supId, quantity, LocalDate.now()));
        }
    }

}
