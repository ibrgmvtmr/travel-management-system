package kg.devcats.coffee_sale.controller.mvc;

import kg.devcats.coffee_sale.payload.request.MerchInventoryRequest;
import kg.devcats.coffee_sale.payload.response.MerchInventoryResponse;
import kg.devcats.coffee_sale.service.MerchInventoryService;
import kg.devcats.coffee_sale.service.SupplierService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/merch-inventory")
public class MerchInventoryControllerMvc {

    private final SupplierService supplierService;
    private final MerchInventoryService merchInventoryService;

    public MerchInventoryControllerMvc(SupplierService supplierService, MerchInventoryService merchInventoryService) {
        this.supplierService = supplierService;
        this.merchInventoryService = merchInventoryService;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("inventories", merchInventoryService.getAll());
        return "merchinventory/list";
    }

    @GetMapping("/create")
    public String showCreateForm(Model model) {
        model.addAttribute("inventory", new MerchInventoryRequest(null, "", 1, 0, null));
        model.addAttribute("suppliers", supplierService.getAll());
        return "merchinventory/create";
    }

    @PostMapping("/create")
    public String create(@ModelAttribute MerchInventoryRequest request) {
        merchInventoryService.create(request);
        return "redirect:/merch-inventory";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        MerchInventoryResponse response = merchInventoryService.getById(id);
        MerchInventoryRequest request = new MerchInventoryRequest(
                response.itemId(),
                response.itemName(),
                response.supId(),
                response.quantity(),
                response.lastUpdated()
        );
        model.addAttribute("inventory", request);
        model.addAttribute("suppliers", supplierService.getAll());
        return "merchinventory/edit";
    }

    @PostMapping("/edit")
    public String update(@ModelAttribute MerchInventoryRequest request) {
        merchInventoryService.update(request.itemId(), request);
        return "redirect:/merch-inventory";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable("id") Long id) {
        merchInventoryService.delete(id);
        return "redirect:/merch-inventory";
    }
}
