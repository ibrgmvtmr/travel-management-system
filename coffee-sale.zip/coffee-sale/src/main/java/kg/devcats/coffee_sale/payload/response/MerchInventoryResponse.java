package kg.devcats.coffee_sale.payload.response;

import java.time.LocalDate;

public record MerchInventoryResponse(

        Long itemId,
        String itemName,
        Integer supId,
        String supplierName,
        Integer quantity,
        LocalDate lastUpdated

) {}
