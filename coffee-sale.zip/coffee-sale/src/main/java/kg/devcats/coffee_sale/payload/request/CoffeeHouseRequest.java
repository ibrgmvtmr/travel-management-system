package kg.devcats.coffee_sale.payload.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

public record CoffeeHouseRequest(

        @NotNull(message = "Store ID is required")
        Integer id,

        @NotBlank(message = "City is required")
        String city,

        @PositiveOrZero(message = "Coffee sales must be zero or positive")
        Integer coffeeSales,

        @PositiveOrZero(message = "Merch sales must be zero or positive")
        Integer merchSales,

        @PositiveOrZero(message = "Total sales must be zero or positive")
        Integer totalSales

) {}
