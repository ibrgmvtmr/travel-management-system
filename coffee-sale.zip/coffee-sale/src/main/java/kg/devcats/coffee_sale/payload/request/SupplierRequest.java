package kg.devcats.coffee_sale.payload.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record SupplierRequest(

        @NotNull(message = "Supplier ID is required")
        Integer supId,

        @NotBlank(message = "Supplier name is required")
        @Size(max = 100, message = "Supplier name must not exceed 100 characters")
        String supName,

        @Size(max = 100, message = "Street must not exceed 100 characters")
        String street,

        @Size(max = 50, message = "City must not exceed 50 characters")
        String city,

        @Size(max = 50, message = "State must not exceed 50 characters")
        String state,

        @Size(max = 10, message = "ZIP code must not exceed 10 characters")
        String zip

) {}
