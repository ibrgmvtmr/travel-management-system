package kg.devcats.coffee_sale.controller.mvc;

import jakarta.validation.Valid;
import kg.devcats.coffee_sale.payload.request.SupplierRequest;
import kg.devcats.coffee_sale.service.SupplierService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/suppliers")
public class SupplierControllerMvc {

    private final SupplierService supplierService;

    public SupplierControllerMvc(SupplierService supplierService) {
        this.supplierService = supplierService;
    }

    @GetMapping
    public String listSuppliers(Model model) {
        model.addAttribute("suppliers", supplierService.getAll());
        return "supplier/list";
    }

    @GetMapping("/create")
    public String showCreateForm(Model model) {
        model.addAttribute("supplier", new SupplierRequest(null, "", "", "", "", ""));
        return "supplier/create"; // Новое представление для создания
    }

    @PostMapping("/create")
    public String createSupplier(@Valid @ModelAttribute("supplier") SupplierRequest request,
                                 BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "supplier/create";
        }
        supplierService.create(request);
        return "redirect:/suppliers";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Integer supId, Model model) {
        model.addAttribute("supplier", supplierService.getById(supId));
        return "supplier/edit"; // Новое представление для редактирования
    }

    @PostMapping("/edit/{id}")
    public String updateSupplier(@PathVariable("id") Integer supId,
                                 @Valid @ModelAttribute("supplier") SupplierRequest request,
                                 BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "supplier/edit";
        }
        supplierService.update(supId, request);
        return "redirect:/suppliers";
    }

    @PostMapping("/delete/{id}")
    public String deleteSupplier(@PathVariable("id") Integer supId) {
        supplierService.delete(supId);
        return "redirect:/suppliers";
    }
}
