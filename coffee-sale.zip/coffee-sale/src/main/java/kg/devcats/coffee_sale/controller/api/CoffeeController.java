package kg.devcats.coffee_sale.controller.api;

import kg.devcats.coffee_sale.payload.request.CoffeeRequest;
import kg.devcats.coffee_sale.payload.response.CoffeeResponse;
import kg.devcats.coffee_sale.service.CoffeeService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/coffees")
public class CoffeeController {

    private final CoffeeService coffeeService;

    public CoffeeController(CoffeeService coffeeService) {
        this.coffeeService = coffeeService;
    }

    @PostMapping
    public ResponseEntity<CoffeeResponse> create(@RequestBody CoffeeRequest request) {
        return ResponseEntity.ok(coffeeService.create(request));
    }

    @GetMapping("/{cofName}/{supId}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    public ResponseEntity<CoffeeResponse> getById(@PathVariable String cofName,
                                                  @PathVariable Integer supId) {
        return ResponseEntity.ok(coffeeService.getById(cofName, supId));
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    public ResponseEntity<List<CoffeeResponse>> getAll() {
        return ResponseEntity.ok(coffeeService.getAll());
    }

    @PutMapping("/{cofName}/{supId}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    public ResponseEntity<CoffeeResponse> update(@PathVariable String cofName,
                                                 @PathVariable Integer supId,
                                                 @RequestBody CoffeeRequest request) {
        return ResponseEntity.ok(coffeeService.update(cofName, supId, request));
    }

    @DeleteMapping("/{cofName}/{supId}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    public ResponseEntity<Void> delete(@PathVariable String cofName,
                                       @PathVariable Integer supId) {
        coffeeService.delete(cofName, supId);
        return ResponseEntity.noContent().build();
    }
}
