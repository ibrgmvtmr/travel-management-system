package kg.devcats.coffee_sale.payload.response;

public record CoffeeHouseResponse(

        Integer id,
        String city,
        Integer coffeeSales,
        Integer merchSales,
        Integer totalSales

) {}
