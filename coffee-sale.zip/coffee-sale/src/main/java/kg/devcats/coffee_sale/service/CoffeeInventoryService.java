package kg.devcats.coffee_sale.service;

import kg.devcats.coffee_sale.payload.request.CoffeeInventoryRequest;
import kg.devcats.coffee_sale.payload.response.CoffeeInventoryResponse;

import java.util.List;

public interface CoffeeInventoryService {

    CoffeeInventoryResponse create(CoffeeInventoryRequest request);

    CoffeeInventoryResponse getById(Integer warehouseId, String cofName, Integer supId);

    List<CoffeeInventoryResponse> getAll();

    CoffeeInventoryResponse update(Integer warehouseId, String cofName, Integer supId, CoffeeInventoryRequest request);

    void delete(Integer warehouseId, String cofName, Integer supId);
}
