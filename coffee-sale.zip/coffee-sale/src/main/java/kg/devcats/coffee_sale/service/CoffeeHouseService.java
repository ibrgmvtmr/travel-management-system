package kg.devcats.coffee_sale.service;

import kg.devcats.coffee_sale.payload.request.CoffeeHouseRequest;
import kg.devcats.coffee_sale.payload.response.CoffeeHouseResponse;

import java.util.List;

public interface CoffeeHouseService {

    CoffeeHouseResponse create(CoffeeHouseRequest request);

    CoffeeHouseResponse getById(Integer id);

    List<CoffeeHouseResponse> getAll();

    CoffeeHouseResponse update(Integer id, CoffeeHouseRequest request);

    void delete(Integer id);
}
