package kg.devcats.coffee_sale.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.PositiveOrZero;

import java.time.LocalDate;

@Entity
@Table(name = "cof_inventory")
public class CoffeeInventory {

    @EmbeddedId
    @NotNull(message = "Inventory ID must not be null")
    private CoffeeInventoryId id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumns({
            @JoinColumn(name = "cof_name", referencedColumnName = "cof_name", insertable = false, updatable = false),
            @JoinColumn(name = "sup_id", referencedColumnName = "sup_id", insertable = false, updatable = false)
    })
    private Coffee coffee;

    @NotNull(message = "Quantity must not be null")
    @PositiveOrZero(message = "Quantity must be zero or positive")
    @Column(name = "quan")
    private Integer quantity;

    @NotNull(message = "Last updated date must not be null")
    @PastOrPresent(message = "Date must be in the past or present")
    @Column(name = "date_val")
    private LocalDate lastUpdated;
    ;

    public CoffeeInventoryId getId() {
        return id;
    }

    public void setId(CoffeeInventoryId id) {
        this.id = id;
    }

    public Coffee getCoffee() {
        return coffee;
    }

    public void setCoffee(Coffee coffee) {
        this.coffee = coffee;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public LocalDate getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(LocalDate lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
}