package kg.devcats.coffee_sale.service;

import kg.devcats.coffee_sale.payload.request.CoffeeRequest;
import kg.devcats.coffee_sale.payload.response.CoffeeResponse;

import java.util.List;

public interface CoffeeService {

    CoffeeResponse create(CoffeeRequest request);

    CoffeeResponse getById(String cofName, Integer supId);

    List<CoffeeResponse> getAll();

    CoffeeResponse update(String cofName, Integer supId, CoffeeRequest request);

    void delete(String cofName, Integer supId);

}
