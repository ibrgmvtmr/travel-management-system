package kg.devcats.coffee_sale.controller.mvc;

import kg.devcats.coffee_sale.payload.request.CoffeeHouseRequest;
import kg.devcats.coffee_sale.payload.response.CoffeeHouseResponse;
import kg.devcats.coffee_sale.service.CoffeeHouseService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/coffee-houses")
public class CoffeeHouseControllerMvc {

    private final CoffeeHouseService coffeeHouseService;

    public CoffeeHouseControllerMvc(CoffeeHouseService coffeeHouseService) {
        this.coffeeHouseService = coffeeHouseService;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("houses", coffeeHouseService.getAll());
        return "coffeehouse/list";
    }

    @GetMapping("/create")
    public String showCreateForm(Model model) {
        model.addAttribute("house", new CoffeeHouseRequest(null, "", 0, 0, 0));
        return "coffeehouse/create";
    }

    @PostMapping("/create")
    public String create(@ModelAttribute CoffeeHouseRequest request) {
        coffeeHouseService.create(request);
        return "redirect:/coffee-houses";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Integer id, Model model) {
        CoffeeHouseResponse response = coffeeHouseService.getById(id);
        model.addAttribute("house", new CoffeeHouseRequest(
                response.id(),
                response.city(),
                response.coffeeSales(),
                response.merchSales(),
                response.totalSales()
        ));
        return "coffeehouse/edit";
    }

    @PostMapping("/edit/{id}")
    public String update(@PathVariable Integer id, @ModelAttribute CoffeeHouseRequest request) {
        coffeeHouseService.update(id, request);
        return "redirect:/coffee-houses";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Integer id) {
        coffeeHouseService.delete(id);
        return "redirect:/coffee-houses";
    }
}
