package kg.devcats.coffee_sale.controller.api;

import kg.devcats.coffee_sale.payload.request.MerchInventoryRequest;
import kg.devcats.coffee_sale.payload.response.MerchInventoryResponse;
import kg.devcats.coffee_sale.service.MerchInventoryService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/merch-inventories")
public class MerchInventoryController {

    private final MerchInventoryService service;

    public MerchInventoryController(MerchInventoryService service) {
        this.service = service;
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    public ResponseEntity<MerchInventoryResponse> create(@RequestBody MerchInventoryRequest request) {
        return ResponseEntity.ok(service.create(request));
    }

    @GetMapping("/{itemId}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    public ResponseEntity<MerchInventoryResponse> getById(@PathVariable Long itemId) {
        return ResponseEntity.ok(service.getById(itemId));
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    public ResponseEntity<List<MerchInventoryResponse>> getAll() {
        return ResponseEntity.ok(service.getAll());
    }

    @PutMapping("/{itemId}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    public ResponseEntity<MerchInventoryResponse> update(@PathVariable Long itemId,
                                                         @RequestBody MerchInventoryRequest request) {
        return ResponseEntity.ok(service.update(itemId, request));
    }

    @DeleteMapping("/{itemId}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    public ResponseEntity<Void> delete(@PathVariable Long itemId) {
        service.delete(itemId);
        return ResponseEntity.noContent().build();
    }
}

