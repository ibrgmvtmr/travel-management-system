package kg.devcats.coffee_sale.repository;

import jakarta.transaction.Transactional;
import kg.devcats.coffee_sale.entity.Coffee;
import kg.devcats.coffee_sale.entity.CoffeeId;
import kg.devcats.coffee_sale.entity.Supplier;
import kg.devcats.coffee_sale.payload.request.CoffeeRequest;
import kg.devcats.coffee_sale.payload.response.CoffeeResponse;
import kg.devcats.coffee_sale.repository.jpa.h2.CoffeeH2Jpa;
import kg.devcats.coffee_sale.repository.jpa.postgres.CoffeePostgresJpa;
import kg.devcats.coffee_sale.repository.jpa.postgres.SupplierPostgresJpa;
import kg.devcats.coffee_sale.service.CoffeeService;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class CoffeeRepository implements CoffeeService {

    private final CoffeePostgresJpa postgresRepo;
    private final CoffeeH2Jpa h2Repo;
    private final SupplierPostgresJpa supplierRepo;

    public CoffeeRepository(CoffeePostgresJpa postgresRepo, CoffeeH2Jpa h2Repo, SupplierPostgresJpa supplierRepo) {
        this.postgresRepo = postgresRepo;
        this.h2Repo = h2Repo;
        this.supplierRepo = supplierRepo;
    }

    @Override
    public CoffeeResponse create(CoffeeRequest request) {
        Supplier supplier = supplierRepo.findById(request.supId())
                .orElseThrow(() -> new RuntimeException("Supplier not found"));

        Coffee coffee = new Coffee();
        coffee.setId(new CoffeeId(request.cofName(), request.supId()));
        coffee.setSupplier(supplier);
        coffee.setPrice(request.price());
        coffee.setSales(request.sales());
        coffee.setTotal(request.total());

        Coffee savedPostgres = postgresRepo.save(coffee);
        h2Repo.save(coffee);

        return mapToResponse(savedPostgres);
    }

    @Override
    @Transactional
    public CoffeeResponse getById(String cofName, Integer supId) {
        Coffee coffee = postgresRepo.findById(new CoffeeId(cofName, supId))
                .orElseThrow(() -> new RuntimeException("Coffee not found in PostgreSQL"));
        return mapToResponse(coffee);
    }

    @Override
    public List<CoffeeResponse> getAll() {
        List<Coffee> coffees = postgresRepo.findAll();
        List<CoffeeResponse> result = new ArrayList<>();
        for (Coffee coffee : coffees) {
            result.add(mapToResponse(coffee));
        }
        return result;
    }

    @Override
    public CoffeeResponse update(String cofName, Integer supId, CoffeeRequest request) {
        CoffeeId id = new CoffeeId(cofName, supId);
        Coffee coffee = postgresRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Coffee not found"));

        coffee.setPrice(request.price());
        coffee.setSales(request.sales());
        coffee.setTotal(request.total());

        Coffee updated = postgresRepo.save(coffee);
        h2Repo.save(coffee);

        return mapToResponse(updated);
    }

    @Override
    public void delete(String cofName, Integer supId) {
        CoffeeId id = new CoffeeId(cofName, supId);
        postgresRepo.deleteById(id);
        h2Repo.deleteById(id);
    }

    private CoffeeResponse mapToResponse(Coffee coffee) {
        return new CoffeeResponse(
                coffee.getId().getCofName(),
                coffee.getId().getSupId(),
                coffee.getPrice(),
                coffee.getSales(),
                coffee.getTotal()
        );
    }
}
