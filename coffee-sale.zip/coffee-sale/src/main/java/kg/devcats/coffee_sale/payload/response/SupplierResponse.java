package kg.devcats.coffee_sale.payload.response;

public record SupplierResponse(

        Integer supId,
        String supName,
        String street,
        String city,
        String state,
        String zip

) {}
