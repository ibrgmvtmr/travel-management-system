package kg.devcats.coffee_sale.repository.jpa.postgres;

import kg.devcats.coffee_sale.entity.Coffee;
import kg.devcats.coffee_sale.entity.CoffeeId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CoffeePostgresJpa extends JpaRepository<Coffee, CoffeeId> {
}
