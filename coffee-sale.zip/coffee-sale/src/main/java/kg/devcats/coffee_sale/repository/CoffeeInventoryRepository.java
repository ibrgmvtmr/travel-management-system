package kg.devcats.coffee_sale.repository;

import kg.devcats.coffee_sale.entity.Coffee;
import kg.devcats.coffee_sale.entity.CoffeeInventory;
import kg.devcats.coffee_sale.entity.CoffeeInventoryId;
import kg.devcats.coffee_sale.payload.request.CoffeeInventoryRequest;
import kg.devcats.coffee_sale.payload.response.CoffeeInventoryResponse;
import kg.devcats.coffee_sale.repository.jpa.h2.CoffeeInventoryH2Jpa;
import kg.devcats.coffee_sale.repository.jpa.postgres.CoffeeInventoryPostgresJpa;
import kg.devcats.coffee_sale.repository.jpa.postgres.CoffeePostgresJpa;
import kg.devcats.coffee_sale.service.CoffeeInventoryService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CoffeeInventoryRepository implements CoffeeInventoryService {

    private final CoffeeInventoryPostgresJpa postgresRepo;
    private final CoffeeInventoryH2Jpa h2Repo;
    private final CoffeePostgresJpa coffeeRepo;

    public CoffeeInventoryRepository(CoffeeInventoryPostgresJpa postgresRepo,
                                     CoffeeInventoryH2Jpa h2Repo,
                                     CoffeePostgresJpa coffeeRepo) {
        this.postgresRepo = postgresRepo;
        this.h2Repo = h2Repo;
        this.coffeeRepo = coffeeRepo;
    }

    @Override
    public CoffeeInventoryResponse create(CoffeeInventoryRequest request) {
        Coffee coffee = coffeeRepo.findById(new kg.devcats.coffee_sale.entity.CoffeeId(request.cofName(), request.supId()))
                .orElseThrow(() -> new RuntimeException("Coffee not found"));

        CoffeeInventory inventory = mapToEntity(request);
        inventory.setCoffee(coffee);

        CoffeeInventory saved = postgresRepo.save(inventory);
        h2Repo.save(inventory);

        return mapToResponse(saved);
    }

    @Override
    public CoffeeInventoryResponse getById(Integer warehouseId, String cofName, Integer supId) {
        CoffeeInventoryId id = new CoffeeInventoryId();
        id.setWarehouseId(warehouseId);
        id.setCoffeeName(cofName);
        id.setSupplierId(supId);

        CoffeeInventory inventory = postgresRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Inventory not found"));

        return mapToResponse(inventory);
    }

    @Override
    public List<CoffeeInventoryResponse> getAll() {
        List<CoffeeInventory> list = postgresRepo.findAll();
        List<CoffeeInventoryResponse> result = new ArrayList<>();
        for (CoffeeInventory inv : list) {
            result.add(mapToResponse(inv));
        }
        return result;
    }

    @Override
    public CoffeeInventoryResponse update(Integer warehouseId, String cofName, Integer supId, CoffeeInventoryRequest request) {
        CoffeeInventoryId id = new CoffeeInventoryId();
        id.setWarehouseId(warehouseId);
        id.setCoffeeName(cofName);
        id.setSupplierId(supId);

        CoffeeInventory inventory = postgresRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Inventory not found"));

        inventory.setQuantity(request.quantity());
        inventory.setLastUpdated(request.lastUpdated());

        CoffeeInventory updated = postgresRepo.save(inventory);
        h2Repo.save(inventory);

        return mapToResponse(updated);
    }

    @Override
    public void delete(Integer warehouseId, String cofName, Integer supId) {
        CoffeeInventoryId id = new CoffeeInventoryId();
        id.setWarehouseId(warehouseId);
        id.setCoffeeName(cofName);
        id.setSupplierId(supId);

        postgresRepo.deleteById(id);
        h2Repo.deleteById(id);
    }

    private CoffeeInventory mapToEntity(CoffeeInventoryRequest r) {
        CoffeeInventory ci = new CoffeeInventory();
        CoffeeInventoryId id = new CoffeeInventoryId();
        id.setWarehouseId(r.warehouseId());
        id.setCoffeeName(r.cofName());
        id.setSupplierId(r.supId());
        ci.setId(id);
        ci.setQuantity(r.quantity());
        ci.setLastUpdated(r.lastUpdated());
        return ci;
    }

    private CoffeeInventoryResponse mapToResponse(CoffeeInventory ci) {
        CoffeeInventoryId id = ci.getId();
        return new CoffeeInventoryResponse(
                id.getWarehouseId(),
                id.getCoffeeName(),
                id.getSupplierId(),
                ci.getQuantity(),
                ci.getLastUpdated()
        );
    }
}

