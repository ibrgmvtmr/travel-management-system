package kg.devcats.coffee_sale.controller.api;

import kg.devcats.coffee_sale.payload.request.CoffeeInventoryRequest;
import kg.devcats.coffee_sale.payload.response.CoffeeInventoryResponse;
import kg.devcats.coffee_sale.service.CoffeeInventoryService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/coffee-inventories")
public class CoffeeInventoryController {

    private final CoffeeInventoryService service;


    public CoffeeInventoryController(CoffeeInventoryService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<CoffeeInventoryResponse> create(@RequestBody CoffeeInventoryRequest request) {
        return ResponseEntity.ok(service.create(request));
    }

    @GetMapping("/{warehouseId}/{cofName}/{supId}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    public ResponseEntity<CoffeeInventoryResponse> getById(@PathVariable Integer warehouseId,
                                                           @PathVariable String cofName,
                                                           @PathVariable Integer supId) {
        return ResponseEntity.ok(service.getById(warehouseId, cofName, supId));
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    public ResponseEntity<List<CoffeeInventoryResponse>> getAll() {
        return ResponseEntity.ok(service.getAll());
    }

    @PutMapping("/{warehouseId}/{cofName}/{supId}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    public ResponseEntity<CoffeeInventoryResponse> update(@PathVariable Integer warehouseId,
                                                          @PathVariable String cofName,
                                                          @PathVariable Integer supId,
                                                          @RequestBody CoffeeInventoryRequest request) {
        return ResponseEntity.ok(service.update(warehouseId, cofName, supId, request));
    }

    @DeleteMapping("/{warehouseId}/{cofName}/{supId}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
    public ResponseEntity<Void> delete(@PathVariable Integer warehouseId,
                                       @PathVariable String cofName,
                                       @PathVariable Integer supId) {
        service.delete(warehouseId, cofName, supId);
        return ResponseEntity.noContent().build();
    }
}

