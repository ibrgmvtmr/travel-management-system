package kg.devcats.coffee_sale.service;

import kg.devcats.coffee_sale.payload.request.MerchInventoryRequest;
import kg.devcats.coffee_sale.payload.response.MerchInventoryResponse;

import java.util.List;

public interface MerchInventoryService {

    MerchInventoryResponse create(MerchInventoryRequest request);

    MerchInventoryResponse getById(Long itemId);

    List<MerchInventoryResponse> getAll();

    MerchInventoryResponse update(Long itemId, MerchInventoryRequest request);

    void delete(Long itemId);
}
