package kg.devcats.coffee_sale.security;

import kg.devcats.coffee_sale.entity.User;
import kg.devcats.coffee_sale.repository.jpa.h2.UserH2Jpa;
import kg.devcats.coffee_sale.repository.jpa.postgres.UserPostgresJpa;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserDetailsServiceImpl implements org.springframework.security.core.userdetails.UserDetailsService {

    private final UserPostgresJpa userPostgresJpa;
    private final UserH2Jpa userH2Jpa;

    public UserDetailsServiceImpl(UserPostgresJpa userPostgresJpa, UserH2Jpa userH2Jpa) {
        this.userPostgresJpa = userPostgresJpa;
        this.userH2Jpa = userH2Jpa;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<User> postgresUserOpt = userPostgresJpa.findByUsername(username);
        Optional<User> h2UserOpt = userH2Jpa.findByUsername(username);

        if (postgresUserOpt.isEmpty()) {
            throw new UsernameNotFoundException("Пользователь не найден в PostgreSQL: " + username);
        }

        if (h2UserOpt.isEmpty()) {
            throw new UsernameNotFoundException("Пользователь не найден в H2: " + username);
        }

        User user = postgresUserOpt.get();

        return user;
    }
}
