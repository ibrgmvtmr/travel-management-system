package kg.devcats.coffee_sale.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

import java.util.List;

@Entity
@Table(name = "suppliers")
public class Supplier {

    @Id
    @NotNull
    @Column(name = "sup_id")
    private Integer supId;

    @NotBlank(message = "Supplier name must not be blank")
    @Size(max = 100, message = "Supplier name must not exceed 100 characters")
    @Column(name = "sup_name", length = 100)
    private String supName;

    @Size(max = 100, message = "Street must not exceed 100 characters")
    @Column(name = "street", length = 100)
    private String street;

    @Size(max = 50, message = "City must not exceed 50 characters")
    @Column(name = "city", length = 50)
    private String city;

    @Size(max = 50, message = "State must not exceed 50 characters")
    @Column(name = "state", length = 50)
    private String state;

    @Size(max = 10, message = "ZIP code must not exceed 10 characters")
    @Column(name = "zip", length = 10)
    private String zip;

    @OneToMany(mappedBy = "supplier", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Coffee> coffees;

    public Supplier() {
    }

    public Integer getSupId() {
        return supId;
    }

    public void setSupId(Integer supId) {
        this.supId = supId;
    }

    public String getSupName() {
        return supName;
    }

    public void setSupName(String supName) {
        this.supName = supName;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public List<Coffee> getCoffees() {
        return coffees;
    }

    public void setCoffees(List<Coffee> coffees) {
        this.coffees = coffees;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Supplier)) return false;
        Supplier that = (Supplier) o;
        return supId != null && supId.equals(that.supId);
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }

    @Override
    public String toString() {
        return "Supplier{" +
                "supId=" + supId +
                ", supName='" + supName + '\'' +
                ", city='" + city + '\'' +
                '}';
    }
}
