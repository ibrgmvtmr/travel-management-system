package kg.devcats.coffee_sale.repository.jpa.h2;

import kg.devcats.coffee_sale.entity.CoffeeHouse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CoffeeHouseH2Jpa extends JpaRepository<CoffeeHouse, Integer> {
}
